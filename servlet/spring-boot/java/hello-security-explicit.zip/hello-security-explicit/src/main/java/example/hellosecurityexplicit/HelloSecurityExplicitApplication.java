package example.hellosecurityexplicit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloSecurityExplicitApplication {

	public static void main(String[] args) {
		SpringApplication.run(HelloSecurityExplicitApplication.class, args);
	}

}
